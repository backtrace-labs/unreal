// Sauce Labs Inc. All Rights Reserved.

#include "SauceSample.h"

#include <Modules/ModuleManager.h>

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SauceSample, "SauceSample" );
